/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//galactus/users/link/bartviel45/Documents/2020-2021/FPGA_TP/MPP/sequenceur.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );


static void work_a_0847595724_3212880686_p_0(char *t0)
{
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    unsigned char t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    xsi_set_current_line(24, ng0);
    t1 = (t0 + 992U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 3560);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(25, ng0);
    t3 = (t0 + 1832U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t3 = (t0 + 3656);
    t6 = (t3 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t5;
    xsi_driver_first_trans_fast(t3);
    goto LAB3;

}

static void work_a_0847595724_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned int t11;
    char *t12;
    unsigned char t13;
    static char *nl0[] = {&&LAB3, &&LAB8, &&LAB8, &&LAB4, &&LAB5, &&LAB6, &&LAB7};

LAB0:    xsi_set_current_line(32, ng0);
    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (char *)((nl0) + t3);
    goto **((char **)t1);

LAB2:    xsi_set_current_line(84, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t13 = (t3 == (unsigned char)3);
    if (t13 != 0)
        goto LAB94;

LAB96:
LAB95:    t1 = (t0 + 3576);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(35, ng0);
    t4 = (t0 + 6206);
    t6 = (t0 + 3720);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t4, 4U);
    xsi_driver_first_trans_fast_port(t6);
    xsi_set_current_line(36, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 6210);
    t3 = 1;
    if (2U == 2U)
        goto LAB12;

LAB13:    t3 = 0;

LAB14:    if (t3 != 0)
        goto LAB9;

LAB11:    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 6212);
    t3 = 1;
    if (2U == 2U)
        goto LAB20;

LAB21:    t3 = 0;

LAB22:    if (t3 != 0)
        goto LAB18;

LAB19:
LAB10:    goto LAB2;

LAB4:    xsi_set_current_line(44, ng0);
    t1 = (t0 + 6214);
    t4 = (t0 + 3720);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t1, 4U);
    xsi_driver_first_trans_fast_port(t4);
    xsi_set_current_line(45, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 6218);
    t3 = 1;
    if (2U == 2U)
        goto LAB29;

LAB30:    t3 = 0;

LAB31:    if (t3 != 0)
        goto LAB26;

LAB28:    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 6220);
    t3 = 1;
    if (2U == 2U)
        goto LAB37;

LAB38:    t3 = 0;

LAB39:    if (t3 != 0)
        goto LAB35;

LAB36:    xsi_set_current_line(49, ng0);
    t1 = (t0 + 3784);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);

LAB27:    goto LAB2;

LAB5:    xsi_set_current_line(53, ng0);
    t1 = (t0 + 6222);
    t4 = (t0 + 3720);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t1, 4U);
    xsi_driver_first_trans_fast_port(t4);
    xsi_set_current_line(54, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 6226);
    t3 = 1;
    if (2U == 2U)
        goto LAB46;

LAB47:    t3 = 0;

LAB48:    if (t3 != 0)
        goto LAB43;

LAB45:    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 6228);
    t3 = 1;
    if (2U == 2U)
        goto LAB54;

LAB55:    t3 = 0;

LAB56:    if (t3 != 0)
        goto LAB52;

LAB53:    xsi_set_current_line(58, ng0);
    t1 = (t0 + 3784);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);

LAB44:    goto LAB2;

LAB6:    xsi_set_current_line(62, ng0);
    t1 = (t0 + 6230);
    t4 = (t0 + 3720);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t1, 4U);
    xsi_driver_first_trans_fast_port(t4);
    xsi_set_current_line(63, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 6234);
    t3 = 1;
    if (2U == 2U)
        goto LAB63;

LAB64:    t3 = 0;

LAB65:    if (t3 != 0)
        goto LAB60;

LAB62:    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 6236);
    t3 = 1;
    if (2U == 2U)
        goto LAB71;

LAB72:    t3 = 0;

LAB73:    if (t3 != 0)
        goto LAB69;

LAB70:    xsi_set_current_line(67, ng0);
    t1 = (t0 + 3784);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);

LAB61:    goto LAB2;

LAB7:    xsi_set_current_line(71, ng0);
    t1 = (t0 + 6238);
    t4 = (t0 + 3720);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t1, 4U);
    xsi_driver_first_trans_fast_port(t4);
    xsi_set_current_line(72, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 6242);
    t3 = 1;
    if (2U == 2U)
        goto LAB80;

LAB81:    t3 = 0;

LAB82:    if (t3 != 0)
        goto LAB77;

LAB79:    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 6244);
    t3 = 1;
    if (2U == 2U)
        goto LAB88;

LAB89:    t3 = 0;

LAB90:    if (t3 != 0)
        goto LAB86;

LAB87:    xsi_set_current_line(76, ng0);
    t1 = (t0 + 3784);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);

LAB78:    goto LAB2;

LAB8:    xsi_set_current_line(80, ng0);
    t1 = (t0 + 6246);
    t4 = (t0 + 3720);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t1, 4U);
    xsi_driver_first_trans_fast_port(t4);
    xsi_set_current_line(81, ng0);
    t1 = (t0 + 3784);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    goto LAB2;

LAB9:    xsi_set_current_line(37, ng0);
    t7 = (t0 + 3784);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t12 = *((char **)t10);
    *((unsigned char *)t12) = (unsigned char)3;
    xsi_driver_first_trans_fast(t7);
    goto LAB10;

LAB12:    t11 = 0;

LAB15:    if (t11 < 2U)
        goto LAB16;
    else
        goto LAB14;

LAB16:    t5 = (t2 + t11);
    t6 = (t1 + t11);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB13;

LAB17:    t11 = (t11 + 1);
    goto LAB15;

LAB18:    xsi_set_current_line(39, ng0);
    t7 = (t0 + 3784);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t12 = *((char **)t10);
    *((unsigned char *)t12) = (unsigned char)6;
    xsi_driver_first_trans_fast(t7);
    goto LAB10;

LAB20:    t11 = 0;

LAB23:    if (t11 < 2U)
        goto LAB24;
    else
        goto LAB22;

LAB24:    t5 = (t2 + t11);
    t6 = (t1 + t11);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB21;

LAB25:    t11 = (t11 + 1);
    goto LAB23;

LAB26:    xsi_set_current_line(46, ng0);
    t7 = (t0 + 3784);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t12 = *((char **)t10);
    *((unsigned char *)t12) = (unsigned char)4;
    xsi_driver_first_trans_fast(t7);
    goto LAB27;

LAB29:    t11 = 0;

LAB32:    if (t11 < 2U)
        goto LAB33;
    else
        goto LAB31;

LAB33:    t5 = (t2 + t11);
    t6 = (t1 + t11);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB30;

LAB34:    t11 = (t11 + 1);
    goto LAB32;

LAB35:    xsi_set_current_line(48, ng0);
    t7 = (t0 + 3784);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t12 = *((char **)t10);
    *((unsigned char *)t12) = (unsigned char)6;
    xsi_driver_first_trans_fast(t7);
    goto LAB27;

LAB37:    t11 = 0;

LAB40:    if (t11 < 2U)
        goto LAB41;
    else
        goto LAB39;

LAB41:    t5 = (t2 + t11);
    t6 = (t1 + t11);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB38;

LAB42:    t11 = (t11 + 1);
    goto LAB40;

LAB43:    xsi_set_current_line(55, ng0);
    t7 = (t0 + 3784);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t12 = *((char **)t10);
    *((unsigned char *)t12) = (unsigned char)5;
    xsi_driver_first_trans_fast(t7);
    goto LAB44;

LAB46:    t11 = 0;

LAB49:    if (t11 < 2U)
        goto LAB50;
    else
        goto LAB48;

LAB50:    t5 = (t2 + t11);
    t6 = (t1 + t11);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB47;

LAB51:    t11 = (t11 + 1);
    goto LAB49;

LAB52:    xsi_set_current_line(57, ng0);
    t7 = (t0 + 3784);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t12 = *((char **)t10);
    *((unsigned char *)t12) = (unsigned char)3;
    xsi_driver_first_trans_fast(t7);
    goto LAB44;

LAB54:    t11 = 0;

LAB57:    if (t11 < 2U)
        goto LAB58;
    else
        goto LAB56;

LAB58:    t5 = (t2 + t11);
    t6 = (t1 + t11);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB55;

LAB59:    t11 = (t11 + 1);
    goto LAB57;

LAB60:    xsi_set_current_line(64, ng0);
    t7 = (t0 + 3784);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t12 = *((char **)t10);
    *((unsigned char *)t12) = (unsigned char)6;
    xsi_driver_first_trans_fast(t7);
    goto LAB61;

LAB63:    t11 = 0;

LAB66:    if (t11 < 2U)
        goto LAB67;
    else
        goto LAB65;

LAB67:    t5 = (t2 + t11);
    t6 = (t1 + t11);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB64;

LAB68:    t11 = (t11 + 1);
    goto LAB66;

LAB69:    xsi_set_current_line(66, ng0);
    t7 = (t0 + 3784);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t12 = *((char **)t10);
    *((unsigned char *)t12) = (unsigned char)4;
    xsi_driver_first_trans_fast(t7);
    goto LAB61;

LAB71:    t11 = 0;

LAB74:    if (t11 < 2U)
        goto LAB75;
    else
        goto LAB73;

LAB75:    t5 = (t2 + t11);
    t6 = (t1 + t11);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB72;

LAB76:    t11 = (t11 + 1);
    goto LAB74;

LAB77:    xsi_set_current_line(73, ng0);
    t7 = (t0 + 3784);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t12 = *((char **)t10);
    *((unsigned char *)t12) = (unsigned char)3;
    xsi_driver_first_trans_fast(t7);
    goto LAB78;

LAB80:    t11 = 0;

LAB83:    if (t11 < 2U)
        goto LAB84;
    else
        goto LAB82;

LAB84:    t5 = (t2 + t11);
    t6 = (t1 + t11);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB81;

LAB85:    t11 = (t11 + 1);
    goto LAB83;

LAB86:    xsi_set_current_line(75, ng0);
    t7 = (t0 + 3784);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t12 = *((char **)t10);
    *((unsigned char *)t12) = (unsigned char)5;
    xsi_driver_first_trans_fast(t7);
    goto LAB78;

LAB88:    t11 = 0;

LAB91:    if (t11 < 2U)
        goto LAB92;
    else
        goto LAB90;

LAB92:    t5 = (t2 + t11);
    t6 = (t1 + t11);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB89;

LAB93:    t11 = (t11 + 1);
    goto LAB91;

LAB94:    xsi_set_current_line(85, ng0);
    t1 = (t0 + 3784);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    goto LAB95;

}


extern void work_a_0847595724_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0847595724_3212880686_p_0,(void *)work_a_0847595724_3212880686_p_1};
	xsi_register_didat("work_a_0847595724_3212880686", "isim/tb_sequenceur_isim_beh.exe.sim/work/a_0847595724_3212880686.didat");
	xsi_register_executes(pe);
}
